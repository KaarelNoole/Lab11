package com.noole.lab11;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.ArrayList;

public class DayAdapter extends RecyclerView.Adapter<DayAdapter.DayViewHolder>{

    private ArrayList<Day> dayList;

    public DayAdapter() {
        this.dayList = new ArrayList<>();
    }

    @NonNull
    @Override
    public DayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_day,parent,false);
        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DayViewHolder holder, int position) {
        Day day = dayList.get(position);
        holder.info.setText(day.getInfo());
        holder.currentTemperature.setText(day.getCurrentTemp());
        holder.feelsTemperature.setText(day.getFeelTemp());
        holder.humidity.setText(day.getHumidity());
        holder.speed.setText(day.getSpeed());
        holder.sunriser.setText(day.getSunrise());
        holder.sunset.setText(day.getSunset());
        holder.description.setText(day.getDescription());
        Picasso.get().load(day.getIcon()).into(holder.icon);
    }

    @Override
    public int getItemCount() {
        return dayList.size();
    }

    public void setDayList(final ArrayList<Day> dayList){this.dayList = dayList; notifyDataSetChanged();}

    static class DayViewHolder extends RecyclerView.ViewHolder{
        private final TextInputEditText info;
        private final TextInputEditText currentTemperature;
        private final TextInputEditText feelsTemperature;
        private final TextInputEditText description;
        private final TextInputEditText humidity;
        private final TextInputEditText speed;
        private final TextInputEditText sunriser;
        private final TextInputEditText sunset;
        private final ImageView icon;


        public DayViewHolder(@NonNull View itemView){
            super(itemView);
            info = itemView.findViewById(R.id.txtWeatherInfo);
            currentTemperature = itemView.findViewById(R.id.txtCurrentTemp);
            feelsTemperature = itemView.findViewById(R.id.txtFeelsTemp);
            description = itemView.findViewById(R.id.txtDescription);
            humidity = itemView.findViewById(R.id.txtHumidity);
            speed = itemView.findViewById(R.id.txtWindSpeed);
            sunriser = itemView.findViewById(R.id.txtSunrise);
            sunset = itemView.findViewById(R.id.txtSunset);
            icon = itemView.findViewById(R.id.imgWeatherIcon);
        }
    }
}
